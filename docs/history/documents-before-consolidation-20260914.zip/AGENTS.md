- 2026-09-14 00:42 Asia/Shanghai 最新用户授权：立即修复并持续推进原10名Kimi居民生活、
  原10个DeepSeek后台GM观察/开发新功能/同档续跑的最小MVP，工作到2026-09-14 09:00
  Asia/Shanghai（01:00 UTC）。此项取代下方仅只读巡检、不修复不重启，以及24小时试运行期限。
  GPT-6负责方向、建模、派发和验收；工程优先使用gpt-5.3-codex-spark、DeepSeek deepseek-flash，
  Kimi继续原居民路由。最多两个工程执行者，文件不重叠；实际世界与生产GM运行期冻结全部tracked
  文件和HEAD，修改/提交在关闭窗口。复用会话和原账本，保留历史未知、去重、冷却与原币种预算。
  局部居民错误应隔离并送GM观察，不能笼统挡住所有GM；存档/身份/计费未知等真正全局故障仍保留停止。
  以真实GM参与及至少一项新功能进入同一世界、居民实际使用作为交付，不以预检或fixture替代。
  允许为修复MVP链条而调度、验证并恢复真实运行，无需为普通代码错误反复询问；不外部推送。
  截止前留足结算/关闭时间，到09:00保存真实检查点并暂停自动任务。原15分钟心跳改为持续推进此工作。

- 2026-09-13 晚间用户方向（只读与24小时部分已被上方09点任务覆盖）：让原有10个Kimi居民自主生活，
  原有10个DeepSeek后台GM自主维护/开发；GPT-6每15分钟只读检查是否符合预期，不决定居民行动、
  不指定GM修法、不逐轮审批交付。启动前所需的最小接线与工程验证由GPT-5.6/DeepSeek完成。
  正式循环须使用原世界、原身份/历史、原费用账本和既有冷却/去重；不能用新井边fixture或脚本模型冒充。
  已授权自动运行及既定范围内经宿主验证的本地版本交付，不包含外部推送或任意扩大代码修改范围。
  程序自动处理有限子进程、持久化与发布边界，GPT的巡检不能替代这些运行控制。
  正常无变化巡检保持安静；实际停止、异常、关键交付或需要用户处理时才通知。巡检本身不启动新模型、
  不代替GM修复、不自动重置存档/身份/费用。保留所有历史未知；按MODEL_WORKFLOW已记录的支持路径处理
  可结转的中断，不能把unknown改成零费用或重放旧请求。Kimi新增未知与原币种费用上限规则保持不变。
  接线阶段须明确标为准备中，只有实际过程与记录证明后才能称10+10已运行。以下旧限时记录保留为历史。

- 2026-09-13 当前操作规则（tracked-repository freeze，技术性纠正，不是新的用户许可门槛）：
  在**任何**实际canonical世界模型运行或生产GM runner运行期间，冻结**全部tracked文件与Git HEAD**——包括
  docs与提交，因为GM runner的guard覆盖整个仓库HEAD/worktree。此窗口内只允许互不冲突的**private**准备工作并行
  （例如只写tmp/的recipe或capture协调器）；被审核的源码/文档提交应集中放在**无活跃运行的暂停/发布窗口**批量落地。
  该规则源于 task31编排事故：root在十GM观察期间提交了ROADMAP/STATUS（063a1f9f→77e8169，仅2个文档文件），
  五个显式protected文件哈希全部未变，但整个批次被记为 incomplete / runner exit 1；十份GM回复本身10/10结构化有效，
  73条disposition（55 no_action + 18 observe）、0新issue、0 coding claim，也没有新增未知。整批并未通过，
  这些回复也不是新的代码贡献；不得重放其付费调用，不得削弱GM guard。
  工程人员池（GPT-5.6-sol、gpt-5.3-codex-spark、DeepSeek deepseek-flash）、最多两名工程师并发、canonical世界单写者、
  Kimi居民与后台GM的provider/账本/冷却设置、10:00 Asia/Shanghai截止与前序历史未知均保持不变。

- 2026-09-13 latest user routing (current; no instruction time asserted): continue the agreed chain through
  2026-09-13 10:00 Asia/Shanghai (02:00 UTC). GPT-6 keeps direction, modeling, dispatch and
  outcome acceptance only. GPT-5.6-sol, gpt-5.3-codex-spark and DeepSeek `deepseek-flash` perform
  engineering/code/tests. Current disjoint ownership assigns the H36 runtime task to DeepSeek,
  the GM-candidate isolation fix to GPT-5.6-sol, and the bounded routing-document task to Spark;
  this assignment does not make DeepSeek the only permitted coder. Production Kimi-resident and
  background DeepSeek-GM runtime assignments stay unchanged. Default is at most two engineers
  concurrently with disjoint ownership and only one maintained-world writer. The future checkpoint
  is 09:50; do not start
  work that cannot finish by 10:00, pause heartbeat at cutoff, preserve owned-process identity, and
  close only task-owned processes. Unknown DeepSeek development tails remain unknown under the prior
  carried-continuation rule; Kimi unknown/currency stops are unchanged.
  Prior 2026-09-12 08:00/15:00 windows remain historical and not active.

- 2026-09-13 01:48 Asia/Shanghai previous routing note: same chain with DeepSeek plus Codex5.3Spark
  assistance, with DeepSeek as implementation/test executor in its one reused native session and a
  separate read-only Spark audit on immutable snapshot only. This now remains historical and is fully
  superseded on implementation by the 10:00 routing above.

- 2026-09-12 15:32 Asia/Shanghai user routing (previous): return to the original
  GPT-6 Extra High supervisor plus DeepSeek implementation/execution workflow and
  continue iteration toward the actual ten-Kimi-resident + ten-DeepSeek-background-GM
  world. The GPT-6-only window ended at 15:00 the same day, so that timed override below
  is expired and is not in force; its text stays only as history. GPT-6 owns planning,
  dispatch, validation and review; DeepSeek owns implementation, execution and routine
  test/fix loops in its own reused native session. The development DeepSeek worker itself
  does not recursively invoke providers from its own tool dispatches; explicit
  supervisor-bounded real Kimi/GM runtime runs remain part of the authorized goal and
  still require the existing carried ledger and scope. Production resident/GM provider
  assignments are unchanged and ten-Kimi + ten-DeepSeek operation has now started: the first real ten-resident Kimi cycle and the first real ten-GM DeepSeek observation both ran on 2026-09-12 (see docs/validation/real_ten_2026-09-12/report.md). The first real GM repair loop has since closed: gm-09 read evidence, wrote and tested code in an isolated candidate, and its eight reviewed files were released into main after independent review, with the same world continuing and cold-restoring. The first bounded resident/GM repair-loop MVP passed; continuous service and the later M20 acceptances remain open. This is one phased bounded loop, not continuous 20-agent operation, spontaneous GM discovery, general GM visibility or sustainable economic life. The prior stream-interruption
  exception and all carried accounting remain; old failures are preserved, never erased.
  The five-GPT6-Ultra parallel sprint was a time-limited window that expired at 15:00 the same day; its text is history only. The supervisor operational interpretation of the standing user instructions (unlimited cheap DeepSeek calls; "do not stop, directly finish and test real 10+10") is recorded in docs/MODEL_WORKFLOW.md: an interrupted DeepSeek usage tail is preserved as unknown and the scoped work continues through a recorded recovery, without repeated approval merely for that bookkeeping gap. That is not a new user reply, not a settled or zero charge, and not authorization for unbounded unattended runs; the Kimi ledger, new-uncertainty stop and currency bounds are unchanged. See docs/MODEL_WORKFLOW.md for this machine's verified launcher.

- 2026-09-12 latest user override, active until 2026-09-12 15:00 Asia/Shanghai (07:00 UTC): use GPT-6 only for planning, implementation, execution, testing and review, with FIVE GPT-6 Ultra subagents in parallel plus the supervisor. No DeepSeek or Kimi API dispatches during this window. This explicitly overrides earlier sole-DeepSeek execution and two-worker limits for this window; no recursive delegation. Advance useful MVP work and preserve measured accounting, existing saves and unfinished work. The user means the shared quota refresh at 15:00, not redeeming a reset credit. Keep production resident/GM provider assignments unchanged; offline/mock validation is not a real Kimi/DeepSeek 10+10 run. Checkpoint safely at the deadline; do not automatically launch paid providers then.

- 2026-09-12 latest route review: the user explicitly requested two GPT-6 subagents plus the GPT-6 supervisor to review short- and long-term direction before implementation resumes. Their independent reviews and one cross-rebuttal round are recorded in docs/validation/route_review_2026-09-12.md. They found local execution drift, corrected the route, and left no unresolved user-level route decision. Resume only along the corrected ROADMAP: a persistent independent ten-resident trial world, ten real Kimi residents and ten DeepSeek GMs, at least one attributable GM repair/delivery and same-world resident continuation; session counts/cache are not completion. Fix world identity/genesis before paid life begins, preserve failures and old worlds, distinguish GM discovery from supervisor-specified investigation, and do not add generic monitoring/deployment, full occupations or long-soak prerequisites. This review-specific GPT-6 delegation does not change DeepSeek's sole implementation/execution role or reset accounting.

- 2026-09-12 current-task exception: the user explicitly authorized continuing after the single DeepSeek stream failure recorded at 02:26:15 UTC. Preserve that unresolved usage/charge as unknown and continue the supervised resident/GM-chain work without replaying completed tools. This is an exception for that incident, not a zero-cost entry, blanket waiver for future unknown charges, NPC-budget reset or overnight-automation restart.

- 2026-09-12: User authorized consolidating and pushing main with continuous iteration
  until 2026-09-12 08:00 Asia/Shanghai. GPT6 plans and reviews; DeepSeek implements.
  The prior no-unattended sentence is superseded for this time-limited run. The prior
  DeepSeek development request/currency caps are removed; measured usage and historical
  costs are preserved. NPC inference budgets are unchanged. Actual evidence is required
  before any green; no self-imposed batch-stop. Existing Windows routing and continuity
  rules remain. No competing plan.

# Project instructions

- Latest route correction after source audit, 2026-09-12: start a simple shared world with 10 Kimi residents pursuing their own needs and 10 independent BACKGROUND GMs all driven by DeepSeek. GMs observe runtime/scene/collision evidence, identify defects or missing capabilities, then own reading, implementation and test/fix loops. NPCs receive personal life consequences, never developer diagnostics or bug-hunting duties. Do not require a completed economy/art pass, a fixed 3+2-to-5+3 ladder or a 24-hour soak before first joint operation. Reuse the town runtime; connect the missing observation/need-to-GM/execution paths first. Source findings and limitations are in docs/ARCHITECTURE.md; progress stays in the original ROADMAP M20/H25-H28. Model image support/pricing must be verified before claiming it. This planning correction does not itself launch an unattended paid run.

- Latest planning decision, 2026-09-12: the next formal shared-world milestone is M20 in the ORIGINAL ROADMAP: 10 persistent Kimi residents plus 10 independent BACKGROUND AI GMs. GMs continuously develop/maintain the game, respond to real resident needs or explicit proactive proposals, and retain their own task/maintainer history; they are not ten extra ordinary NPCs. NPC contexts must not contain developer tasks, code, test logs or GM internal discussions; residents learn actual world changes through attributed perception/use. This supersedes old population/GM-only-future ordering, not the single-writer, independent validation, continuity or bounded paid-run rules. GPT-6 owns this roadmap/design work; DeepSeek owns development implementation, execution and routine test/fix loops. The milestone plan does not itself launch 20 agents or reopen the expired overnight authorization. Follow M20 acceptance and later N5-N10 directions without creating a competing roadmap.

Read this file, README.md and docs/STATUS.md first; then only the relevant gate in ROADMAP.md and the files needed for the task. User instructions take precedence.

- Current execution policy (2026-09-12): GPT-6 owns thinking, scope, dispatch, validation and review; DeepSeek owns development implementation and execution, including routine test/fix loops. Use `deepseek-flash` (currently DeepSeek-V4.1-Flash), verified against the official API; do not silently substitute a model or have the supervisor implement rejected core fixes. The user removed the prior USD 1 / three-request limit for authorized DeepSeek iteration. Keep actual usage, known historical charges, failures and per-delivery stop conditions; unlimited calls do not expand the project scope or authorize unattended runs.

- One goal: an enterable, consequential, persistent AI world whose residents survive model changes. Latest user scope (2026-09-10): the well package is only an internal technical preview. Continue art and gameplay to the original Kimi town's verified capabilities and then 5–10 active residents before calling it the first version. Public licensing/external testing are publication gates, not blockers for authorized internal development.
- This is the formal project's single-engine Godot direction. The old UE repository is a reference and recovery source; no wholesale copy, parallel engine rewrite or automatic world reset.
- Do not invent an NPC's success, knowledge, capabilities or resources. The world validates actions; models propose choices. Label fixtures, replay, local fallback and real model decisions accurately.
- Preserve private source saves and identity/history. Write migrations to separate outputs and report unsupported data. Public snapshots are not restore saves. Only one writer owns a maintained world.
- Search exact files or bounded modules first with rg; exclude binaries, cache, generated output and vendor content. Never scan the entire workspace by default. Check load before an unavoidable broad search.
- Spawn subagents only when the user explicitly requests delegation. Default to one bounded worker, at most two in parallel; do not copy the entire conversation or allow recursive delegation. Close workers when finished.
- Scope each batch to one visible result and ROADMAP.md limits. Record root and worker usage increments, not repeated cumulative counts. No automatic hard token limiter exists; unknown measurement stops new dispatches. Failure does not authorize extra time, budget or a replacement project.
- Current user cadence (2026-09-10): review direction after each visible delivery and formally at every 100,000,000 raw development tokens. Count cached input once as part of input, and keep currency billing separate. Use actual session counters and the ignored ledger via tools/record_agent_usage.py. The user permits small Codex 5.3-family/Kimi tasks and reused conversations; verify availability and accounting, never silently substitute models or claim guaranteed cache hits.
- Paid model runs require their authorized scope, original carried ledger, cooldowns and a current stop condition. This repository's creation does not start such a run or reset an allowance. Never commit API keys, private configs or fee databases.
- Record owned long-lived process IDs. Clean up only processes started by the task; do not leave engines, model loops, helpers or workers running.
- Validate consequential world behavior and persistence; do not repeat engine checks for low-risk documentation edits. Report limits honestly.
- User instruction, 2026-09-11: critically challenge proposed mechanisms before executing them. State the strongest concrete objection, a counterexample and the smallest useful validation; distinguish evidence from assumptions. Disagree when the mechanism undermines the persistent-world goal, including with the supervisor's earlier proposals. Do not manufacture disagreement or claim a design can be proven infallible. Resolve ordinary code errors independently; escalate unresolved world semantics, not routine implementation choices.
- After every Luna implementation, the supervisor must assess direction using actual evidence: does this improve resident choice, visible consequences, persistence/model replacement, or delivery of the first playable street? Record one supported gain, the remaining goal gap and one next step in docs/STATUS.md. A library, passing fixture or more code alone does not establish autonomous life. Stop adding features when a round only grows infrastructure or repeats a proven demo.
- Keep Luna engineering assignments small enough to produce a first patch after at most two bounded read batches. If that is not possible, require a concrete missing interface/blocker and rescope before spending more on analysis. Do not treat hitting a token checkpoint without a patch as useful implementation progress.
- Keep a single roadmap and short status entry. Do not accumulate competing plans, expired night-run instructions or speculative platform work.
- User direction, 2026-09-11: roadmap/architecture reviews must use GPT-6 (currently gpt-6-astra), not Luna. Luna remains eligible for bounded engineering. When three reviewers are requested, use independent views and one bounded cross-rebuttal round; distinguish review hypotheses from observed failures and close reviewers afterward.
- Latest user correction, 2026-09-11, supersedes the earlier uninterrupted-development requirement: continuity means the SAME world's identities, history, property and commitments survive pause, exit, version updates and restart. The user may explicitly pause the world; feature development may stop and resume independently. Default to demand-driven, tested version releases and same-save migration/continuation. Hot loading, live GM/NPC admission and simultaneous development/operation are optional future capabilities, not current acceptance gates. Keep useful module boundaries without building a general live-update platform. Never interpret restarting the game as permission to reset its world.
- Before publishing a migrated asset, verify redistribution and dependencies. Never import the source project's restricted character files or private state. Public visibility does not select a license.

- User direction, 2026-09-11: maintain the canonical progress diagram and node evidence table in ROADMAP.md after each bounded delivery. Verified nodes turn green only within their labeled evidence scope; add newly discovered problems as child nodes with stable IDs and acceptance criteria. Keep unresolved/recurring problems visible. Do not replace the diagram or create competing execution roadmaps.

- Latest user correction, 2026-09-11: keep ALL progress and discovered functional problems on the original full-horizon roadmap graph, not separate small diagrams. Continue the active implementation loop without stopping at self-imposed raw-token checkpoints. Keep measuring usage and making bounded engineering/model runs; do not silently enlarge currency authorization or erase historical costs. Report substantive progress in commentary and continue ordinary fixes; stop for user cancellation, actual unavailable authorization/resources, or unresolved world semantics rather than invented batch gates.

- Latest user decision, 2026-09-11 (development execution routing): ALL development execution (implementation, bug fixes, asset operations, shell commands and tests) is delegated to DeepSeek deepseek-flash. GPT-6 discusses alternatives, challenges direction and reviews reported outcomes with the user; it must not silently resume implementation or dispatch Luna when DeepSeek fails. This overrides earlier executor assignments and the multi-GPT-6 code-review workflow; a model error returns a concrete report. Routing/dispatching an authorized DeepSeek task is orchestration. Game NPC runtime provider changes are a separate explicit implementation scope, not performed by changing development routing. All unrelated instructions and same-world constraints above remain in force. See docs/MODEL_WORKFLOW.md for the launcher.
