# publish.ps1 review report — 2026-09-11

Artifact: `Transfer/publication-20260911/publish.ps1` (PowerShell 5.1, native git only).
Not executed for publication here. Reviewer ran a syntax parse and a read-only
`-Preflight` run only.

## Run

    powershell -NoProfile -ExecutionPolicy Bypass -File publish.ps1 -Preflight   # read-only checks
    powershell -NoProfile -ExecutionPolicy Bypass -File publish.ps1              # commit + push

Target: active worktree `C:\Users\quchenxi\.codex\worktrees\0b50\InfiniteAincrad`,
branch `codex/publish-street-20260910`, expected base HEAD `e3ab07b`.
Remote accepted: only `https://github.com/dotafs2/InfiniteAincrad[.git]` or
`git@github.com:dotafs2/InfiniteAincrad[.git]`.

## What it does

1. Re-verifies toplevel == active root, branch, origin URL, clean index, HEAD.
2. Reads the 86 reviewed paths from `publication-file-list.txt`; refuses any dirty
   path outside that set + the two intended additions, and any reviewed path missing.
3. Path safety: rejects absolute/`..` paths, disallowed extensions, and any symlink
   or reparse point on the candidate or its ancestor chain.
4. Secret screening over candidate text files (`sk-*`, key/secret/password/
   authorization/token assignments, PEM blocks). Prints filenames + class only.
   The exemption is narrowed to the exact reviewed dummy sentinel literal
   `DO-NOT-LEAK-prompt-body-42`, and only inside its own reviewed file
   `tools/test_deepseek_usage.py`: that one literal is removed from the scanned
   text before matching. Any other secret-like value, including a real key placed
   in that file, still matches and blocks. No key values are printed.
5. Asserts the 2 tracked LFS objects exist locally at the reviewed sizes.
6. Copies `scripts/deepseek.py` from the package only if missing/identical; fails on
   any differing destination. Adds `docs/GOALS.md` (shared root copy, SHA-pinned) with
   a historical top note; fails if the destination already exists. Applies the exact
   six-run `docs/STATUS.md` sentence correction; idempotent if already corrected,
   fails on unknown text.
7. Stages ONLY the explicit reviewed paths + those two additions, then verifies the
   staged set: any staged path outside the reviewed set fails closed. A reviewed
   path legitimately absent from the staged names (content already equals HEAD,
   e.g. `StartingTown_Market_CraftV5.glb.import` stat/EOL-only dirt) is allowed
   only after proving it is tracked (`git ls-files --error-unmatch`) and
   `git diff --quiet HEAD -- <path>` exits 0; an untracked intended source fails
   instead of being silently omitted. Then runs `git diff --cached --check`.
8. Commits, pushes `-u origin codex/publish-street-20260910` (no force, no --no-verify),
   then confirms `git ls-remote` sha == local HEAD before writing `pushed-verified`.
9. Writes/updates `upload-state.json` in this package. After a failed push, rerun
   re-pushes only the recorded commit and never an unknown commit. When the recorded
   `commitSha` already equals HEAD and the index/worktree is clean, the rerun skips
   ALL prepare/stage/commit and goes straight to push/verify. A dirty partial
   pre-commit retry is reported as unsupported and fails; it is never guessed at and
   other staged files are never overwritten.

Never: fetch, branch switch, main writes, force-push, reset, delete, tarball extract,
secret move, key/provider config read, Transfer staging.

## Reviewed root diffs — included vs excluded

- Included: `docs/GOALS.md` (2026-09-10 goals/history) with a top note stating
  `ROADMAP.md` + `docs/STATUS.md` take precedence and the body is historical status.
- Excluded (superseded by newer active-branch files, not overwritten):
  root `AGENTS.md` (only adds the "Development model roles" block; active AGENTS.md
  is a newer, broader superset), root `README.md` (only adds the GOALS nav link;
  active README is newer), root `docs/STATUS.md` (09-11 launch preamble now covered
  by the active N3 entries), root `docs/MODEL_WORKFLOW.md` (older than active copy).
- Excluded as historical/not code-relevant: root `docs/validation/plugin_probe_2026-09-10/`
  (2 files; superseded by the 51 active validation files).
- `scripts/deepseek.py`: added for source versioning only; the live launcher stays at
  `C:\InfiniteAincrad\scripts\deepseek.py` and is not executed or moved.

## Static checks actually run

- AST parse: OK (2390 tokens, 0 errors).
- `-Preflight`: OK — preconditions passed, no writes/stage/commit/push.
- Remote regex: accepts the 3 intended URLs, rejects `evil` and `InfiniteAincrad-evil`.
- Traversal regex: rejects `..` and absolute paths.
- Sentinel file: 0 `sk-*` matches, contains the documented dummy string.
- After the corrections: AST parse OK; `-Preflight` still OK (no writes/stage/commit/push).
- Sentinel exemption: only the literal `DO-NOT-LEAK-prompt-body-42` is stripped in
  `tools/test_deepseek_usage.py`; a synthetic real-key value in that file would be
  detected by the unchanged regexes (not exercised against the real worktree here).

## Limitations

- Publication execution is left to the supervisor's normal channel; not verified end to end here.
- Whether the 2 LFS objects are already on the remote is unknown offline.
- `git diff --cached --check` may emit CRLF normalization notes on stderr; only its exit
  code gates. Any git non-zero exit stops the script and is never reported as success.
