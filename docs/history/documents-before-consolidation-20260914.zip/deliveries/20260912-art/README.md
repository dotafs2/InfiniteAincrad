# 起始之城 · 2026-09-12 Blender资产交付

**178件资产，7个Blender源库，242个GLB文件。** 植物32件各有三档LOD，LOD文件不重复计入178件。

这是静态美术交付：尚未接入居民逻辑、碰撞、导航或存档。组合街角样板未完成，以下提供真实单件/套件渲染与检查记录。

| 类别 | 模型数 | 可编辑源文件 | GLB目录 |
| --- | ---: | --- | --- |
| 庭院植物 | 32 | [StartingTown_GardenBotanicals32](Art/Generated/GardenBotanicals20260912/StartingTown_GardenBotanicals32.blend) | [打开](game/assets/generated/garden_botanicals_20260912/) |
| 街道公共构件 | 36 | [Street_Structures_Library](Art/Generated/StreetStructures20260912/Street_Structures_Library.blend) | [打开](game/assets/generated/street_structures_20260912/) |
| 市集与生活用品 | 40 | [market_life_library](Art/Generated/MarketLife20260912/market_life_library.blend) | [打开](game/assets/generated/market_life_20260912/) |
| 店面外立面 | 16 | [ShopfrontDetails20260912](Art/Generated/ShopfrontDetails20260912/ShopfrontDetails20260912.blend) | [打开](game/assets/generated/shopfront_details_20260912/) |
| 职业工坊设备 | 18 | [artisan_workshops_library](Art/Generated/ArtisanWorkshops20260912/artisan_workshops_library.blend) | [打开](game/assets/generated/artisan_workshops_20260912/) |
| 旅行与河岸运输 | 36 | [river_trade_library](Art/Generated/TravelCargo20260912/river_trade_library.blend) · [travel_cargo_library](Art/Generated/TravelCargo20260912/travel_cargo_library.blend) | [打开](game/assets/generated/travel_cargo_20260912/) |

## 图集与检查

- [植物总览](docs/validation/art_batch_20260912/garden/catalogue.png) · [32张单件图](docs/validation/art_batch_20260912/garden/cards/)
- [40件市集与室内用品](docs/validation/art_batch_20260912/market/REPORT.md) · [40张单件图](docs/validation/art_batch_20260912/market/cards/)
- [36件街道组件图集](docs/validation/art_batch_20260912/street/README.md)
- [另一个并行会话的70件补充资产图集](docs/validation/art_parallel_20260912/README.md)

全部242个最终GLB通过统一格式/索引/有限坐标/内嵌依赖检查，退化小三角0；Godot4.7.2逐件离线导入242/242通过。复制后逐文件SHA256复核通过。详细证据：[GLB检查](docs/validation/art_batch_20260912/glb_audit.json)、[Godot导入](docs/validation/art_batch_20260912/godot_import.json)、[交付清单](delivery.json)。原版井/市集/住宅未计入新增178件。

## 使用

在Blender5.2.1打开上表.blend源库；向Godot拖入所需GLB即可查看静态模型。源文件采用米/Z向上，GLB采用标准Y向上。植物的额外UV保留风动权重，但静态GLB本身不等于已接入动画。各套件的生成脚本保留在对应源目录；植物依赖的项目自有mesh helper已附带。

最新代码与原项目模型已下载到 `C:/InfiniteAincrad/tmp/art-20260912`，提交71f7640；95个LFS文件约962MB，哈希核验通过。原始 `C:/InfiniteAincrad` 未提交改动和私有存档未合并覆盖。来源记录见[source_receipt.json](docs/validation/art_batch_20260912/source_receipt.json)。本次没有提交或推送。

均为项目原创/项目自有辅助代码生成的本地美术资产，未加入受限角色或私人状态。项目整体许可仍未选定，本交付不擅自指定开源许可证。

账号额度观察从32%已用变为46%已用，包含同时进行的会话，不能精确归因给本线程；未使用reset。已完成工作在15:00北京时间前冻结。
