# First-floor market and household library — 2026-09-12

40 distinct original props for the established warm, stylized medieval street.
The library uses oak, sage/cream canvas, muted terracotta, dark iron and brass.
The models are newly authored procedural geometry; no character, private save,
anime image, external texture, add-on or restricted source builder is imported.

## Files and use

- `build_market_life.py`: deterministic seeded Blender generator.
- `market_life_library.blend`: editable source library with 40 named `ML_`
  collections and 40 asset-browser-marked source meshes at metric scale.
- `manifest.json`: per-asset dimensions, bounds, triangles, materials and hashes.
- `../../../game/assets/generated/market_life_20260912/`: 40 independent GLBs.
- `../../../docs/validation/art_batch_20260912/market/`: actual Blender renders,
  independent binary GLB audit, library reopen audit and work report.
- `../../../docs/validation/art_batch_20260912/market/cards/index.json`: all 40
  models with individual 640px previews, names, source dimensions and hashes.

The saved Blend opens as a presentation scene. `PRESENTATION_ONLY` contains
linked display copies, labels, lights and the ground. Its display copies are
scaled individually to make small household objects legible in the catalog.
The original `ML_` collections are hidden in the viewport and renderer; unhide
the desired collection in the Outliner to edit the full-scale source. Source
object local geometry has its ground at Z = 0. All GLBs were exported from those
original objects at the origin, without presentation labels, floors or lights.

Run with Blender 5.2.1 LTS (tested) or a compatible 4.5+ installation:

```powershell
& 'C:/Program Files (x86)/Steam/steamapps/common/Blender/blender.exe' --background --threads 4 --python Art/Generated/MarketLife20260912/build_market_life.py
python docs/validation/art_batch_20260912/market/audit_glb.py
```

The generator writes its own outputs and produces a catalog plus five detail
renders. It uses constant, export-safe metallic/roughness PBR materials, modeled
surface details and UV0 on every primitive. No material relies on Blender-only
procedural shader nodes. Source is metres/Z-up; glTF uses the exporter's standard
Y-up conversion. Geometry dimensions and counts are reproducible for the fixed
seed; byte-identical Blender/glTF serialization is not asserted.

## Scope

The 40 assets cover stalls and trade, provisions, hand crafts, textile work,
household furniture, cooking and personal travel. There are 270,186 visual
triangles across the full library and 10,972,080 bytes across the 40 GLBs.
The independent GLB audit passes 560 checks with zero triangles below area
5e-10 square metres and zero external dependencies.

These are static art assets. Moving parts remain modeled within each editable
source mesh; they have no animation rig, collision shapes, LODs, interaction
scripts, navigation or resident/world-state semantics. The wall shelf requires
placement against a wall. The candle and oil lamp are unlit. Geometry alone does
not establish a mechanically simulated loom, scale, grinder or spinning wheel.
Project-wide redistribution licensing remains the maintainer's decision.
