# Floor-1 street structures · 2026-09-12

36 original medieval town furnishing assets, using the project's established pale limestone, warm oak, dark framing, terracotta, sage, teal iron and restrained brass palette.

Open `Street_Structures_Library.blend`. Each named asset collection is marked for Blender's Asset Browser and contains a named ground-pivot root plus editable mesh geometry. The source library is arranged in a six-column grid; move a collection's `_ROOT` to reposition the complete asset. GLBs are independently exported at their own ground-level placement origin, in metres and standard glTF Y-up. Blender source is Z-up.

The set includes: roofed well, fountain, garden arch gate, shrine, guild board, directional signpost, single and double lamps, stone and timber benches, arched bridge, pergola, timber and iron fences, plank gate, fabric canopy, balcony, shutter window, studded door, hanging sign, wall lantern, entry stair, open belfry, civic clock, sundial, hitching rail, covered arcade, curved balustrade, retaining wall, curb pavement, culvert, timber pier, downpipe and trough, buttress, banner poles and chain bollards.

Each model has actual beveled geometry and metric UV0. Stone, timber and cloth use three original 512×512 surface normal maps. The maps are packed in the Blend and used maps are embedded in each GLB. Materials use glTF-compatible Principled base colour, roughness, metallic and normal inputs. There are no external art dependencies, downloaded images, third-party characters or private source saves. All geometry and the small abstract decorative emblems were authored procedurally for this batch; no SAO frames or proprietary emblems were traced. This provenance statement does not select a repository redistribution license.

Regenerate from the project checkout:

```powershell
& 'C:/Program Files (x86)/Steam/steamapps/common/Blender/blender.exe' --background --threads 4 --python Art/Generated/StreetStructures20260912/build_street_structures.py
python Art/Generated/StreetStructures20260912/audit_exports.py
```

`-- --no-render` skips reference rendering. `-- --only-render --render-start 22 --render-count 14` reads the saved library and renders a selected range. `make_catalogue.py` arranges the actual rendered references; `validate_roundtrip.py` independently imports every GLB and renders four exported examples.

Exports and duplicated machine-readable manifest: `game/assets/generated/street_structures_20260912/`. Validation references and actual export audits: `docs/validation/art_batch_20260912/street/`.

This is an art library. Water is a static opaque surface; clocks, bells, doors, gates, paper notices and cloth are fixed visual states. Facade modules require attachment to appropriately sized walls. It contains one visual detail level, no collisions, navigation, animation, interaction, dynamic notices, water simulation, resident property or save changes. Texture UV0 repeats deliberately; there is no lightmap UV1 or light bake. Godot placement and density/frame-time validation remain separate work. The deterministic generator reproduces geometry and counts; binary Blender/glTF serialization is not asserted to be byte-identical across runs or Blender versions.
