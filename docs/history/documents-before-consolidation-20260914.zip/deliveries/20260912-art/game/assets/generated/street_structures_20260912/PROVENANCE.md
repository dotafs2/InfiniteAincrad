# Street structures 2026-09-12

36 original procedural Blender assets by the InfiniteAincrad art batch, matching the existing project's broad medieval Floor-1 visual language. Source, generator and three authored packed surface-normal images are in `Art/Generated/StreetStructures20260912/`.

Each GLB embeds its used images, materials, metre-scale meshes, UV0, normals and tangents. No external files are required for GLB import. See `manifest.json` for actual file SHA-256, triangle/vertex counts, dimensions and material lists, and `docs/validation/art_batch_20260912/street/` for actual reference renders and byte/import audits.

There are no imported animation frames, restricted characters, third-party art files, private saves or copied fictional emblems. Original abstract compass, diamond, leaf and civic ornaments are decorative. Project-wide redistribution licensing is not selected by this file.

Visual-only props: one detail level, no collision, navigation, gameplay, rigging, water simulation or save/world state. Clocks, bells, gates, notices, cloth and water are static representations. Godot integration, animation, density budgets and functional connections remain separate.
