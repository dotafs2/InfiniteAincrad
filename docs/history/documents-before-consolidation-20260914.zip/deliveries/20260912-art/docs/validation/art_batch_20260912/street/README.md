# Street structures · 2026-09-12

36 distinct original street and architectural furnishing assets. This is an art-only library; it creates no resident decision, world resource, property, event or save mutation.

The coherent material palette follows the existing Floor-1 hero and residential kits: pale dressed limestone, warm oak, dark framing, muted terracotta, sage woodwork, teal iron and brass. Modeled details include supported overlapping roof tiles and ridge caps, individual masonry and arch voussoirs, recessed glazing, diamond leadwork, hinge straps, metal studs, interlocking chain links, real open well/bell/trough forms, brackets and braces.

Source: `Art/Generated/StreetStructures20260912/Street_Structures_Library.blend`. It contains named Asset Browser collections with individual placement roots, packed normal maps and editable geometry. The adjacent generator uses seed 91231 and no external art source. Independent exports and full manifest are in `game/assets/generated/street_structures_20260912/`.

`manifest.json` records every name, SHA-256, triangle/vertex count, metre-scale bounding box, material list and embedded dependency. `export_audit.json` independently reads the actual GLB bytes and records the final totals. It checks index ranges, finite positions/UV0/normals/tangents, unit normals and tangents, tangent orthogonality, triangle area at the same 5×10^-10 m² threshold used by the supervisor, ground-level Y-up placement, unshifted export roots, image embedding and matching manifests.

Each asset has a 900×900 actual Blender reference render named after its asset id. The `catalogue_*.jpg` files arrange those renders without repainting them. `roundtrip_audit.json` is produced by independently importing every GLB back into Blender; four `_glb_roundtrip.png` files show the imported exported geometry and materials.

Final result: **36/36 byte audits and 36/36 actual Blender GLB reimports passed**. Delivered exports total **393,477 triangles / 66,988,880 bytes**. All imported bounds and ground origins match the source manifest, and every embedded texture was decoded through an actual RGBA pixel read. The four reimport renders were visually inspected. The first roundtrip validator read `has_data` before Blender lazily decoded packed images; its failed report is retained as `roundtrip_iteration1_lazy_decode.json`. The corrected readback validator passed with no asset-byte change.

Visible corrections made during the batch:

- Moved the well bucket onto the supported rim; the first render exposed an unsupported bucket inside the opening.
- Shortened notice-board post caps that pierced the tile surface, and extended shrine side columns to their stone platform.
- Triangulated bevel-created polygons before export, removed tiny degenerate faces and verified actual exported tangents.
- Repaired collapsed bevel UVs and removed unused optional tangent attributes from plain materials; normal-mapped surfaces retain valid tangents. The earlier audit used a looser area threshold and was superseded by the final stricter audit.
- Separated coincident frame/cap surfaces that produced black seams, and attached both decorative sign and wall-lamp braces to their supporting frames.
- Reduced studio exposure and lighting, restored the darker established hero timber/terracotta palette and increased AgX contrast after the first render washed out the dark framing.
- Rotated the long arcade roof to match its three supported bays.

Blender ran in the background with four render threads and owned-process self-timeouts. `process*.json` and the build logs record the owned process ids; the final cleanup report records their exit status. Blender's optional desktop-thumbnail write warning and API deprecation warnings do not affect asset bytes or render output; no missing-image or tangent warning remains in the final build.

Limits: one visual detail level, no collision, navigation, animation, gameplay connection or Godot placement/performance claim. Water is an opaque static surface; clocks, bells, papers, cloth, gates and doors are static. Facade modules need a supporting wall. UV0 deliberately tiles; there is no UV1 lightmap or light bake. Generated geometry/counts are reproducible; binary file identity across Blender versions or repeat serialization is not claimed. Public repository visibility does not select an asset redistribution license.
