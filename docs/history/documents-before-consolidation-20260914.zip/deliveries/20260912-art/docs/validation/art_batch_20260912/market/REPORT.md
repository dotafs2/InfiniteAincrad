# Market and household art batch — 2026-09-12

The delivery contains 40 distinct Blender-authored market, craft and household
props, 40 standalone GLBs, an editable asset-marked Blend library and a seeded
Python generator. It extends the existing first-floor warm oak, sage/cream
canvas, terracotta and iron/brass vocabulary. This is art-only work.

## Delivered assets

| Group | Distinct models |
| --- | --- |
| Market and trade | Produce stall; bakery counter; draped cloth rack; merchant handcart; merchant balance; ledger/coin/ink tray |
| Food and vessels | Bread cutting board; apple crate; carrot/beet crate; cabbage wicker basket; open grain sack and scoop; tapped barrel; terracotta amphora; glazed pitcher |
| Craft and daily work | Wash tub/board; carpenter workbench; sawhorse/frame saw; carpenter tool caddy; hand-cranked grindstone; open bucket; butter churn; spinning wheel; herb drying rack; three-legged stool |
| Interior furniture | Trestle dining table; spindle chair; quilted bed; domed storage chest; stocked wall shelf; upright weaving loom; sloped writing desk |
| Household and travel | Chamber candlestick; ceramic oil lamp; cooking tripod/cauldron; hearth kettle; cheese/knife board; wash basin/ewer; apothecary case; cobbler last/tool board; strapped travel pack |

The set has 270,186 triangles across all 40 original meshes. GLBs total
10,972,080 bytes. Every source collection is named, every original object is
asset-browser marked, and every export is rooted at the ground with metre
dimensions. `manifest.json` lists exact per-model counts, dimensions, materials,
file sizes and SHA-256 hashes; there is no duplicate-count inflation from LODs
or palette variants.

## Validation and iteration

The independent stdlib GLB audit passes **560/560 checks**: valid GLB 2 headers,
one mesh per file, finite coordinates, indexed triangles, matching triangle
counts/hashes, normals and UV0, metallic/roughness PBR materials, ground origins,
no external buffers/images, and no triangles below area 5e-10 square metres.
See `glb_audit.json`; the audit reads actual exported binary payloads.

First-pass renders were inspected. The first cabbage heads read as plain
spheres, so the final geometry adds nine overlapping curved leaves per head,
wavy lifted margins and raised pale midribs. Wicker interiors were opened, and
the spinning-wheel bobbin was aligned with its drive band. The supervisor's
independent numerical audit found collapsed lathe pole triangles in four
initial exports; the generator now emits one vertex at a pole. All 40 final
exports pass the zero-degenerate check without dropping useful detail.

The original source Blend is reopened by `render_catalog_preview.py`, which
checks the 40 named original meshes/collections, asset marks, metre scene scale,
ground origins, unit object scales and absence of external Blend libraries.
Its smaller contact-sheet render exists because the local image viewer cannot
decode the full 2600-pixel catalog payload reliably; the full render is retained.
The reopen audit passed with 40 original meshes, 40 named source collections,
40 asset marks, unit scale and no linked Blend libraries or external images.

The usable per-model catalog is `cards/index.json`: 40 individual 640×640
Cycles renders from the original metric meshes, with an independently framed
camera for each model. `render_asset_cards.py` creates temporary presentation
copies and asserts original source scales remain unchanged. It does not save a
modified Blend or touch production GLBs. Each card entry carries its source
asset hash, dimensions, triangle count and preview hash.

## Actual render evidence

![Market and household contact sheet](market_contact_sheet_preview.png)

[Full 2600-pixel contact sheet](market_contact_sheet.png) ·
[40 individual card entries](cards/index.json)

![Market stalls and handcart](market_stalls_detail.png)

![Carpentry and spinning craft](craft_detail.png)

![Provisions, pottery and merchant balance](provisions_detail.png)

![Furniture and loom](interior_furniture_detail.png)

![Household cooking and travel props](household_craft_detail.png)

## Dependencies, execution and limits

All production geometry and surface recipes are original generator output.
There are no external textures, model libraries or restricted character files.
Blender's built-in font is used only for presentation labels, which are excluded
from GLBs. Materials use constant export-safe PBR inputs; authored UV0 remains
available for a later texture pass. Project licensing is not selected here.

Blender 5.2.1 LTS used CPU Cycles with at most four threads. Owned process IDs
are recorded in `owned_blender_pid.txt`; first-pass and final-pass stdout/stderr
are retained. Blender reports a desktop thumbnail-cache write failure outside
the workspace during save; the actual Blend save, exports and renders succeed.
No paid model APIs, saves, world loops or gameplay code were used.

No collision/LOD/rig/animation or Godot interaction is provided or claimed by
this worker. Small tools and machine components are editable mesh islands, not
separate animated components. The pantry shelf is wall mounted, candles/lamps are
unlit, and the displayed clothing is static. This batch improves the visible
street and possible household dressing, not autonomous residents or persistence.
