# Two-layer plugin probe: stopped before implementation

Started 2026-09-10, around 08:52 UTC. Proposed limit: 2 hours and 200,000 additional raw development tokens including root and workers. The user authorized a bounded trial and subagents, and requested pluggable capabilities.

Completed: one short-context Luna resident-role response against an explicitly authored test fixture; the worker then exited. The reply is preserved in [resident_reply.json](resident_reply.json). This proves only a model response to that supplied observation. It does not prove a live NPC need, a running game, GM development or a plugin loop.

The root initially read an obsolete session log and did not establish the live usage baseline before dispatch. The active session was then found by a bounded same-thread/date search. Three recorded root completions alone added 397,763 raw tokens, already over the proposed limit. The later counter snapshot is saved locally in `tmp/plugin-probe-20260910/usage_stop.json`; it excludes any completion recorded after that snapshot.

No further worker was dispatched after the overrun was identified. The resident worker is closed; no engines or paid world loops were started. Raising the batch cap was asked explicitly instead of silently renewing it. This is a planning/measurement failure, not a completed implementation.

Pending implementation remains one capability package: a versioned manifest, a validated world action, a GM-only install/remove path, preservation of existing items and history on removal, and a resident use result after installation. Stable authority, save and budget checks stay outside replaceable capability packages. Exact feature semantics remain to be validated by a GM; the supplied obstacle does not predetermine that a new feature is necessary.

GPT-5.3-Codex-Spark was not listed by this session's subagent dispatch interface. It was not used or counted as a separate free quota. Official documentation distinguishes Spark from ordinary GPT-5.3-Codex, and client availability depends on account and rollout: [model documentation](https://learn.chatgpt.com/docs/models).
